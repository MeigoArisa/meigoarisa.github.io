﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace School_Record
{
    public partial class ColorCheckedListBox : CheckedListBox
    {
        public ColorCheckedListBox()
        {
            InitializeComponent();
        }
        protected override void OnDrawItem(DrawItemEventArgs e)
        {
            DrawItemEventArgs e2 =
                new DrawItemEventArgs(
                e.Graphics, 
                e.Font, 
                new Rectangle(e.Bounds.Location, e.Bounds.Size),
                e.Index, 
                e.State, 
                this.CheckedIndices.Contains(e.Index) ? Color.Red : Color.Black,
                e.BackColor
                );
            base.OnDrawItem(e2);
        }
    }
}
